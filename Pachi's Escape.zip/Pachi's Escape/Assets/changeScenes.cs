﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class changeScenes : MonoBehaviour {
    public Transform camera;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            PanRight();
        }
        if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            PanLeft();
        }
    }

    public void PanLeft()
    {
        if (globalVariables.position == 1)
        {
            camera.Translate((float)-11.9, 0, 0);
            globalVariables.position -= 1;
        }
        else if (globalVariables.position == 2)
        {
            camera.Translate((float)((34.86 - 11.9) * (-1)), 0, 0);
            globalVariables.position -= 1;
        }
    }

    public void PanRight()
    {
        if (globalVariables.position == 0){
            camera.Translate((float)11.9, 0, 0);
            globalVariables.position += 1;
        }
        else if (globalVariables.position == 1) {
            camera.Translate((float)(34.86-11.9), 0, 0);
            globalVariables.position += 1;
        }
    }
}
